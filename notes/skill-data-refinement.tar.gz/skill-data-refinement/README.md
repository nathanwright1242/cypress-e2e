# Skill Data Refinement

A skill-upload and refinement pipeline tool with a cold, institutional visual identity. Built with
React + Vite + TypeScript, with full TDD coverage (Vitest unit + component) and Playwright E2E.

## Pages

- **Intake** (`/`) — choose a skill *folder*; it is zipped in the browser, checked against
  storage for a name collision, and uploaded to the wrapper API. Collisions prompt an explicit
  overwrite confirmation.
- **Pipelines** (`/pipelines`) — a Monaco YAML editor preloaded with a refinement-pipeline
  preset; edit and push to the API.
- **Guide** (`/guide`) — a filler handbook describing the artifact lifecycle.

## API contract

The frontend targets a thin wrapper API plus direct bucket reads for collision checks:

| Call | Purpose |
| --- | --- |
| `HEAD {VITE_BUCKET_URL}/{name}.zip` | Collision check — 200 = exists, 404 = absent |
| `POST {VITE_WRAPPER_URL}/upload` | Upload artifact, `multipart/form-data`: `file`, `name`, `overwrite` |
| `POST {VITE_WRAPPER_URL}/pipelines` | Push a YAML pipeline definition (JSON body) |

In development these are intercepted by **MSW** (`src/api/handlers.ts`) so the app runs with no
backend. Point `.env` at your real wrapper to go live — no code changes required.


## Validation

Before zipping, the selected folder is validated client-side (`src/api/validate.ts`):

- a `SKILL.md` must exist at the folder root,
- it must carry YAML frontmatter (a leading `--- ... ---` block) with non-empty `name` and `description` fields.

Blocking failures stop the upload with a clear message. A non-blocking warning is shown when the
frontmatter `name` differs from the folder name (the artifact is always named from the folder).


Pipeline YAML on the Pipelines page is validated live as you type (`src/pages/validatePipeline.ts`):
it must parse as YAML and be a mapping with a `name` and a non-empty `stages` list where every
stage has an `id`. Syntax errors are reported with line numbers, and the push button is disabled
until the pipeline is valid.

## Setup

```bash
npm install
cp .env.example .env     # set VITE_BUCKET_URL and VITE_WRAPPER_URL
npm run dev              # http://localhost:5173  (MSW mocks active in dev)
```

## Testing

```bash
npm test                 # Vitest unit + component (20 tests)
npm run test:e2e         # Playwright E2E — run `npx playwright install` first
```

### Test architecture notes

- `src/api/*.test.ts` run in the **node** environment so they exercise real, spec-compliant
  `FormData`/`Blob`/`fetch` (jsdom's multipart parser is broken). They hit MSW handlers directly.
- `src/components/*.test.{ts,tsx}` run in **jsdom** and unit-isolate the HTTP client with `vi.mock`,
  so they verify orchestration and rendering without realm-crossing binary bodies.

## Code quality

```bash
npm run lint           # ESLint (flat config, TypeScript + React Hooks rules)
npm run format         # Prettier write
npm run format:check   # Prettier check (use in CI)
```

A CI job should run, in order: `npm ci`, `npm run lint`, `npm run format:check`, `npm test`,
`npm run build`, and `npm run test:e2e` (after `npx playwright install --with-deps`).

## Going to production

Swap MSW out by guarding `worker.start()` behind `import.meta.env.DEV` (already done in
`src/main.tsx`) and set the two env vars. The S3 write itself stays server-side in your wrapper;
the browser only reconstructs the bucket URL for the read-only collision check.
