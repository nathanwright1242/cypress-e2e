import JSZip from 'jszip';

interface PathedFile extends File {
  webkitRelativePath: string;
}

function relPath(file: File): string {
  return (file as PathedFile).webkitRelativePath || file.name;
}

/** Derive the artifact name from the uploaded folder's top-level directory. */
export function deriveArtifactName(files: File[]): string {
  for (const f of files) {
    const p = relPath(f);
    if (p.includes('/')) return `${p.split('/')[0]}.zip`;
  }
  return 'skill.zip';
}

/** Zip a set of files (preserving relative folder paths) into a single blob. */
export async function zipFiles(files: File[]): Promise<Blob> {
  if (files.length === 0) throw new Error('no files to zip');
  const zip = new JSZip();
  for (const f of files) {
    // new Response(blob).arrayBuffer() works in both browsers and jsdom,
    // whereas File.prototype.arrayBuffer is missing in jsdom.
    const buf = await new Response(f).arrayBuffer();
    zip.file(relPath(f), buf);
  }
  return zip
    .generateAsync({ type: 'blob', compression: 'DEFLATE' })
    .then((b) => new Blob([b], { type: 'application/zip' }));
}
