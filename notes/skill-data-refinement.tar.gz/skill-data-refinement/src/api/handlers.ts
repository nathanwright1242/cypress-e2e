import { http, HttpResponse } from 'msw';

const BUCKET = import.meta.env.VITE_BUCKET_URL ?? 'https://bucket.test';
const WRAPPER = import.meta.env.VITE_WRAPPER_URL ?? 'https://wrapper.test';

// In-memory store of "uploaded" artifact names, simulating S3 contents.
const stored = new Set<string>(['existing-skill.zip']);

export const handlers = [
  // Collision check: HEAD against reconstructed bucket URL
  http.head(`${BUCKET}/:name`, ({ params }) => {
    const name = String(params.name);
    return stored.has(name)
      ? new HttpResponse(null, { status: 200 })
      : new HttpResponse(null, { status: 404 });
  }),

  // Wrapper upload endpoint (multipart/form-data)
  http.post(`${WRAPPER}/upload`, async ({ request }) => {
    const form = await request.formData();
    const file = form.get('file');
    const name = String(form.get('name'));
    const overwrite = form.get('overwrite') === 'true';
    if (!file) {
      return HttpResponse.json({ error: 'missing file field' }, { status: 400 });
    }
    if (stored.has(name) && !overwrite) {
      return HttpResponse.json({ error: 'artifact exists' }, { status: 409 });
    }
    stored.add(name);
    return HttpResponse.json({ ok: true, name, url: `${BUCKET}/${name}` }, { status: 201 });
  }),

  // Pipelines endpoint (YAML push)
  http.post(`${WRAPPER}/pipelines`, async ({ request }) => {
    const body = (await request.json()) as { name?: string; yaml?: string };
    if (!body.yaml || body.yaml.trim() === '') {
      return HttpResponse.json({ error: 'empty pipeline' }, { status: 400 });
    }
    return HttpResponse.json({ ok: true, name: body.name ?? 'pipeline' }, { status: 201 });
  }),
];

// Test helpers
export const __store = {
  reset: () => {
    stored.clear();
    stored.add('existing-skill.zip');
  },
  add: (n: string) => stored.add(n),
  has: (n: string) => stored.has(n),
};
