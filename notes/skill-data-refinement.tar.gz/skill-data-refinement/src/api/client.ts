const BUCKET = import.meta.env.VITE_BUCKET_URL ?? 'https://bucket.test';
const WRAPPER = import.meta.env.VITE_WRAPPER_URL ?? 'https://wrapper.test';

export interface UploadResult {
  ok: boolean;
  name: string;
  url: string;
}

export interface PipelineResult {
  ok: boolean;
  name: string;
}

/** Reconstruct the public bucket URL for an artifact name. */
export function reconstructUrl(name: string): string {
  return `${BUCKET}/${name}`;
}

/** Collision check: HEAD the reconstructed bucket URL. 200 = exists, 404 = absent. */
export async function artifactExists(name: string): Promise<boolean> {
  const res = await fetch(reconstructUrl(name), { method: 'HEAD' });
  return res.status === 200;
}

/** Upload the zipped artifact to the wrapper API as multipart/form-data. */
export async function uploadArtifact(
  name: string,
  zip: Blob,
  overwrite: boolean,
): Promise<UploadResult> {
  const form = new FormData();
  form.append('file', zip, name);
  form.append('name', name);
  form.append('overwrite', String(overwrite));

  const res = await fetch(`${WRAPPER}/upload`, { method: 'POST', body: form });
  if (!res.ok) {
    const body = (await res.json().catch(() => ({}))) as { error?: string };
    throw new Error(body.error ?? `upload failed (${res.status})`);
  }
  return (await res.json()) as UploadResult;
}

/** Push a YAML pipeline definition to the wrapper API. */
export async function pushPipeline(name: string, yaml: string): Promise<PipelineResult> {
  const res = await fetch(`${WRAPPER}/pipelines`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify({ name, yaml }),
  });
  if (!res.ok) {
    const body = (await res.json().catch(() => ({}))) as { error?: string };
    throw new Error(body.error ?? `pipeline push failed (${res.status})`);
  }
  return (await res.json()) as PipelineResult;
}
