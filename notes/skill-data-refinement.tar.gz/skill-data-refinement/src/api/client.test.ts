// @vitest-environment node
import { describe, it, expect, beforeEach } from 'vitest';
import { artifactExists, uploadArtifact, pushPipeline, reconstructUrl } from './client';
import { __store } from './handlers';

beforeEach(() => __store.reset());

describe('reconstructUrl', () => {
  it('builds the bucket URL from an artifact name', () => {
    expect(reconstructUrl('my-skill.zip')).toMatch(/\/my-skill\.zip$/);
  });
});

describe('artifactExists', () => {
  it('returns true when the artifact is in the bucket', async () => {
    expect(await artifactExists('existing-skill.zip')).toBe(true);
  });
  it('returns false when the artifact is absent', async () => {
    expect(await artifactExists('brand-new.zip')).toBe(false);
  });
});

describe('uploadArtifact', () => {
  it('uploads a new artifact successfully', async () => {
    const blob = new Blob(['data'], { type: 'application/zip' });
    const res = await uploadArtifact('fresh.zip', blob, false);
    expect(res.ok).toBe(true);
    expect(res.name).toBe('fresh.zip');
  });
  it('rejects an upload that collides without overwrite', async () => {
    const blob = new Blob(['data'], { type: 'application/zip' });
    await expect(uploadArtifact('existing-skill.zip', blob, false)).rejects.toThrow(/exists/i);
  });
  it('allows overwrite when explicitly requested', async () => {
    const blob = new Blob(['data'], { type: 'application/zip' });
    const res = await uploadArtifact('existing-skill.zip', blob, true);
    expect(res.ok).toBe(true);
  });
});

describe('pushPipeline', () => {
  it('pushes a non-empty pipeline', async () => {
    const res = await pushPipeline('default', 'name: build\nsteps: []');
    expect(res.ok).toBe(true);
  });
  it('rejects an empty pipeline', async () => {
    await expect(pushPipeline('default', '   ')).rejects.toThrow(/empty/i);
  });
});
