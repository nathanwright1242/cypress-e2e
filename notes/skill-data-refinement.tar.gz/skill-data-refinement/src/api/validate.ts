interface PathedFile extends File {
  webkitRelativePath: string;
}

function relPath(file: File): string {
  return (file as PathedFile).webkitRelativePath || file.name;
}

/**
 * Read a file's text content. Prefers the standard Blob.text(); falls back to
 * FileReader for environments (jsdom) where File lacks .text() and Response
 * mishandles File objects.
 */
async function readText(file: File): Promise<string> {
  if (typeof file.text === 'function') return file.text();
  return new Promise((resolve, reject) => {
    const fr = new FileReader();
    fr.onload = () => resolve(String(fr.result));
    fr.onerror = () => reject(fr.error);
    fr.readAsText(file);
  });
}

export interface SkillMeta {
  name?: string;
  description?: string;
}

export interface ValidationResult {
  ok: boolean;
  errors: string[];
  warnings: string[];
  meta?: SkillMeta;
}

/** Top-level folder name of the selection, or null for a flat selection. */
function topFolder(files: File[]): string | null {
  for (const f of files) {
    const p = relPath(f);
    if (p.includes('/')) return p.split('/')[0];
  }
  return null;
}

/**
 * Parse a minimal subset of YAML frontmatter (leading --- ... --- block).
 * Supports flat `key: value` pairs, which is all a SKILL.md header needs.
 */
function parseFrontmatter(text: string): Record<string, string> | null {
  const normalized = text.replace(/^\uFEFF/, '').replace(/\r\n/g, '\n');
  const match = normalized.match(/^---\n([\s\S]*?)\n---/);
  if (!match) return null;
  const body = match[1];
  const out: Record<string, string> = {};
  for (const line of body.split('\n')) {
    if (!line.trim() || line.trimStart().startsWith('#')) continue;
    const idx = line.indexOf(':');
    if (idx === -1) continue;
    const key = line.slice(0, idx).trim();
    let value = line.slice(idx + 1).trim();
    value = value.replace(/^["']|["']$/g, '');
    out[key] = value;
  }
  return out;
}

const REQUIRED_FIELDS = ['name', 'description'] as const;

/**
 * Validate an uploaded skill folder before it is zipped and sent:
 *   - a SKILL.md must exist at the folder root
 *   - it must carry YAML frontmatter with name + description
 * Returns blocking errors plus non-blocking warnings (e.g. name mismatch).
 */
export async function validateSkill(files: File[]): Promise<ValidationResult> {
  const errors: string[] = [];
  const warnings: string[] = [];

  if (files.length === 0) {
    return { ok: false, errors: ['No files selected.'], warnings };
  }

  const folder = topFolder(files);

  // Find SKILL.md and confirm it sits at the folder root.
  const skillFiles = files.filter((f) => relPath(f).split('/').pop() === 'SKILL.md');
  if (skillFiles.length === 0) {
    errors.push('Missing SKILL.md. A skill folder must contain a SKILL.md file.');
    return { ok: false, errors, warnings };
  }

  const expectedRoot = folder ? `${folder}/SKILL.md` : 'SKILL.md';
  const rootSkill = skillFiles.find((f) => relPath(f) === expectedRoot);
  if (!rootSkill) {
    errors.push(`SKILL.md must be at the folder root (expected ${expectedRoot}).`);
    return { ok: false, errors, warnings };
  }

  const text = await readText(rootSkill);
  const fm = parseFrontmatter(text);
  if (!fm) {
    errors.push('SKILL.md is missing YAML frontmatter (a leading --- ... --- block).');
    return { ok: false, errors, warnings };
  }

  for (const field of REQUIRED_FIELDS) {
    if (!fm[field] || fm[field].trim() === '') {
      errors.push(`Frontmatter is missing required field: ${field}.`);
    }
  }

  if (folder && fm.name && fm.name !== folder) {
    warnings.push(
      `Frontmatter name "${fm.name}" does not match folder name "${folder}". The artifact is named from the folder.`,
    );
  }

  return {
    ok: errors.length === 0,
    errors,
    warnings,
    meta: { name: fm.name, description: fm.description },
  };
}
