import { setupWorker } from 'msw/browser';
import { handlers } from './handlers';

// Dev-only mock of the wrapper API + bucket collision checks.
export const worker = setupWorker(...handlers);
