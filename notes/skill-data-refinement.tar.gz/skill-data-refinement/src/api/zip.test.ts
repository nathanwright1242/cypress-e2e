// @vitest-environment node
import { describe, it, expect } from 'vitest';
import { zipFiles, deriveArtifactName } from './zip';

function makeFile(path: string, content: string): File {
  const f = new File([content], path.split('/').pop() ?? path, { type: 'text/plain' });
  Object.defineProperty(f, 'webkitRelativePath', { value: path });
  return f;
}

describe('deriveArtifactName', () => {
  it('uses the top-level folder name and appends .zip', () => {
    const files = [makeFile('my-skill/SKILL.md', 'x'), makeFile('my-skill/run.py', 'y')];
    expect(deriveArtifactName(files)).toBe('my-skill.zip');
  });
  it('falls back to a default when no folder path is present', () => {
    const f = new File(['x'], 'loose.txt');
    expect(deriveArtifactName([f])).toBe('skill.zip');
  });
});

describe('zipFiles', () => {
  it('produces a non-empty zip blob containing the files', async () => {
    const files = [
      makeFile('my-skill/SKILL.md', '# hello'),
      makeFile('my-skill/run.py', 'print(1)'),
    ];
    const blob = await zipFiles(files);
    expect(blob.size).toBeGreaterThan(0);
    expect(blob.type).toBe('application/zip');
  });
  it('throws when given no files', async () => {
    await expect(zipFiles([])).rejects.toThrow(/no files/i);
  });
});
