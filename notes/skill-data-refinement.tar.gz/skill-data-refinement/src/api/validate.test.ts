// @vitest-environment node
import { describe, it, expect } from 'vitest';
import { validateSkill } from './validate';

function makeFile(path: string, content = 'x'): File {
  const f = new File([content], path.split('/').pop() ?? path, { type: 'text/plain' });
  Object.defineProperty(f, 'webkitRelativePath', { value: path });
  return f;
}

const goodFrontmatter = `---
name: my-skill
description: Refines and enriches data for downstream use.
---

# My Skill
Body content here.
`;

describe('validateSkill', () => {
  it('accepts a folder with a root SKILL.md and valid frontmatter', async () => {
    const files = [
      makeFile('my-skill/SKILL.md', goodFrontmatter),
      makeFile('my-skill/run.py', 'print(1)'),
    ];
    const res = await validateSkill(files);
    expect(res.ok).toBe(true);
    expect(res.errors).toHaveLength(0);
    expect(res.meta?.name).toBe('my-skill');
  });

  it('rejects a folder with no SKILL.md', async () => {
    const files = [makeFile('my-skill/run.py', 'print(1)')];
    const res = await validateSkill(files);
    expect(res.ok).toBe(false);
    expect(res.errors.join(' ')).toMatch(/SKILL\.md/i);
  });

  it('rejects a SKILL.md that is not at the folder root', async () => {
    const files = [makeFile('my-skill/nested/SKILL.md', goodFrontmatter)];
    const res = await validateSkill(files);
    expect(res.ok).toBe(false);
    expect(res.errors.join(' ')).toMatch(/root/i);
  });

  it('rejects missing frontmatter', async () => {
    const files = [makeFile('my-skill/SKILL.md', '# My Skill\nNo frontmatter here.')];
    const res = await validateSkill(files);
    expect(res.ok).toBe(false);
    expect(res.errors.join(' ')).toMatch(/frontmatter/i);
  });

  it('rejects frontmatter missing required name', async () => {
    const fm = `---\ndescription: only a description\n---\n# x`;
    const files = [makeFile('my-skill/SKILL.md', fm)];
    const res = await validateSkill(files);
    expect(res.ok).toBe(false);
    expect(res.errors.join(' ')).toMatch(/name/i);
  });

  it('rejects frontmatter missing required description', async () => {
    const fm = `---\nname: my-skill\n---\n# x`;
    const files = [makeFile('my-skill/SKILL.md', fm)];
    const res = await validateSkill(files);
    expect(res.ok).toBe(false);
    expect(res.errors.join(' ')).toMatch(/description/i);
  });

  it('warns when the frontmatter name does not match the folder name', async () => {
    const fm = `---\nname: different-name\ndescription: A valid description of the skill.\n---\n# x`;
    const files = [makeFile('my-skill/SKILL.md', fm)];
    const res = await validateSkill(files);
    expect(res.ok).toBe(true);
    expect(res.warnings.join(' ')).toMatch(/match/i);
  });

  it('rejects an empty selection', async () => {
    const res = await validateSkill([]);
    expect(res.ok).toBe(false);
    expect(res.errors.join(' ')).toMatch(/no files/i);
  });
});
