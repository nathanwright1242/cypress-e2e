import { NavLink, Route, Routes } from 'react-router-dom';
import { Upload } from './pages/Upload';
import { Guide } from './pages/Guide';
import { Pipelines } from './pages/Pipelines';

export default function App() {
  return (
    <div className="shell">
      <header className="topbar">
        <div className="container topbar-inner">
          <div className="brand">
            <span className="brand-mark">Refinery</span>
            <span className="brand-sub">Skill Data Refinement</span>
          </div>
          <nav className="nav" aria-label="Primary">
            <NavLink to="/" end>
              Intake
            </NavLink>
            <NavLink to="/pipelines">Pipelines</NavLink>
            <NavLink to="/guide">Guide</NavLink>
          </nav>
        </div>
      </header>
      <main>
        <div className="container">
          <Routes>
            <Route path="/" element={<Upload />} />
            <Route path="/pipelines" element={<Pipelines />} />
            <Route path="/guide" element={<Guide />} />
          </Routes>
        </div>
      </main>
      <footer
        className="topbar"
        style={{ borderTop: '1px solid var(--ink-line)', borderBottom: 'none' }}
      >
        <div className="container" style={{ padding: '1.2rem var(--pad)' }}>
          <span
            className="mono"
            style={{ fontSize: '0.7rem', color: 'var(--ink-mute)', letterSpacing: '0.2em' }}
          >
            SKILL DATA REFINEMENT · INTERNAL TOOLING
          </span>
        </div>
      </footer>
    </div>
  );
}
