import { useRef, useState } from 'react';
import { useUpload } from './useUpload';
import { RefineLoader } from './RefineLoader';

// webkitdirectory is non-standard; declare it for TS.
declare module 'react' {
  // eslint-disable-next-line @typescript-eslint/no-unused-vars
  interface InputHTMLAttributes<T> {
    webkitdirectory?: string;
    directory?: string;
  }
}

export function UploadPanel() {
  const {
    phase,
    message,
    artifactName,
    fileCount,
    warnings,
    meta,
    submit,
    confirmOverwrite,
    reset,
  } = useUpload();
  const inputRef = useRef<HTMLInputElement>(null);
  const [picked, setPicked] = useState<File[]>([]);

  const onPick = (e: React.ChangeEvent<HTMLInputElement>) => {
    const files = e.target.files ? Array.from(e.target.files) : [];
    setPicked(files);
  };

  const busy =
    phase === 'validating' || phase === 'zipping' || phase === 'checking' || phase === 'uploading';
  const folderName = picked.length
    ? (picked[0] as File & { webkitRelativePath?: string }).webkitRelativePath?.split('/')[0]
    : null;

  return (
    <section className="panel" aria-labelledby="upload-h">
      <p className="eyebrow">Intake · Form 0x7</p>
      <h2 id="upload-h" style={{ marginTop: '0.4rem' }}>
        Add a skill
      </h2>
      <p style={{ color: 'var(--ink-mute)', maxWidth: '52ch' }}>
        Choose a skill folder. Its contents are validated and compressed in your browser, then sent
        to storage. We check for an existing artifact of the same name before writing.
      </p>

      <div style={{ display: 'flex', gap: '0.8rem', flexWrap: 'wrap', marginTop: '1.2rem' }}>
        <input
          ref={inputRef}
          type="file"
          webkitdirectory=""
          directory=""
          multiple
          onChange={onPick}
          aria-label="Choose skill folder"
          style={{ display: 'none' }}
        />
        <button className="btn btn-ghost" onClick={() => inputRef.current?.click()} disabled={busy}>
          Choose folder
        </button>
        <button
          className="btn"
          onClick={() => submit(picked)}
          disabled={busy || picked.length === 0}
        >
          {busy ? 'Working…' : 'Add skill'}
        </button>
        {(phase === 'done' || phase === 'error') && (
          <button
            className="btn btn-ghost"
            onClick={() => {
              setPicked([]);
              reset();
            }}
          >
            Reset
          </button>
        )}
      </div>

      {folderName && phase === 'idle' && (
        <p className="status mono" style={{ color: 'var(--ink-cyan)' }}>
          Selected: {folderName} · {picked.length} file(s) → {folderName}.zip
        </p>
      )}

      {meta &&
        (phase === 'zipping' ||
          phase === 'checking' ||
          phase === 'uploading' ||
          phase === 'needs-confirm' ||
          phase === 'done') && (
          <div
            className="panel"
            style={{ marginTop: '1rem', background: '#06181b' }}
            aria-label="Skill metadata"
          >
            <p className="eyebrow" style={{ marginBottom: '0.6rem' }}>
              Manifest
            </p>
            <dl
              style={{
                display: 'grid',
                gridTemplateColumns: 'auto 1fr',
                gap: '0.3rem 1rem',
                margin: 0,
              }}
            >
              <dt className="mono" style={{ color: 'var(--ink-mute)', fontSize: '0.78rem' }}>
                name
              </dt>
              <dd
                className="mono"
                style={{ margin: 0, color: 'var(--ink-pale)', fontSize: '0.82rem' }}
              >
                {meta.name ?? '—'}
              </dd>
              <dt className="mono" style={{ color: 'var(--ink-mute)', fontSize: '0.78rem' }}>
                desc
              </dt>
              <dd style={{ margin: 0, color: 'var(--ink-pale)', fontSize: '0.85rem' }}>
                {meta.description ?? '—'}
              </dd>
              <dt className="mono" style={{ color: 'var(--ink-mute)', fontSize: '0.78rem' }}>
                artifact
              </dt>
              <dd
                className="mono"
                style={{ margin: 0, color: 'var(--ink-cyan)', fontSize: '0.82rem' }}
              >
                {artifactName}
              </dd>
            </dl>
          </div>
        )}

      {busy && <RefineLoader label={message ?? 'Working…'} />}

      {message && !busy && (
        <p
          className={
            'status ' +
            (phase === 'error'
              ? 'status-err'
              : phase === 'needs-confirm'
                ? 'status-warn'
                : 'status-ok')
          }
          role="status"
        >
          {message}
          {fileCount && phase === 'error' ? ` (${fileCount} files)` : ''}
        </p>
      )}

      {warnings.length > 0 && phase !== 'error' && (
        <ul className="status status-warn" style={{ margin: 0, paddingLeft: '1.1rem' }}>
          {warnings.map((w) => (
            <li key={w}>{w}</li>
          ))}
        </ul>
      )}

      {phase === 'needs-confirm' && (
        <div
          className="panel"
          style={{ borderColor: 'var(--ink-alarm)', marginTop: '1rem' }}
          role="alertdialog"
          aria-label="Confirm overwrite"
        >
          <p className="mono" style={{ color: 'var(--ink-alarm)', marginTop: 0 }}>
            {artifactName} already exists in storage. Overwrite it?
          </p>
          <div style={{ display: 'flex', gap: '0.8rem' }}>
            <button className="btn btn-alarm" onClick={confirmOverwrite}>
              Overwrite
            </button>
            <button
              className="btn btn-ghost"
              onClick={() => {
                setPicked([]);
                reset();
              }}
            >
              Cancel
            </button>
          </div>
        </div>
      )}
    </section>
  );
}
