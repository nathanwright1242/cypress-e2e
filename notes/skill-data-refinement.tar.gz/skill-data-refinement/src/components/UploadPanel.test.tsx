import { describe, it, expect, beforeEach, vi } from 'vitest';
import { render, screen, waitFor } from '@testing-library/react';
import userEvent from '@testing-library/user-event';

vi.mock('../api/client', () => ({
  artifactExists: vi.fn(),
  uploadArtifact: vi.fn(),
  reconstructUrl: (n: string) => `https://bucket.test/${n}`,
}));
vi.mock('../api/zip', async () => {
  const actual = await vi.importActual<typeof import('../api/zip')>('../api/zip');
  return { ...actual, zipFiles: vi.fn(async () => new Blob(['z'], { type: 'application/zip' })) };
});

import { UploadPanel } from './UploadPanel';
import { artifactExists, uploadArtifact } from '../api/client';

beforeEach(() => {
  vi.mocked(artifactExists).mockReset();
  vi.mocked(uploadArtifact).mockReset();
});

function folderFile(path: string, content?: string): File {
  const folder = path.split('/')[0];
  const body =
    content ??
    (path.endsWith('SKILL.md')
      ? `---\nname: ${folder}\ndescription: A valid description for testing.\n---\n# Skill\n`
      : 'x');
  const f = new File([body], path.split('/').pop()!, { type: 'text/plain' });
  Object.defineProperty(f, 'webkitRelativePath', { value: path });
  return f;
}

describe('UploadPanel', () => {
  it('renders the intake heading and disables submit until a folder is chosen', () => {
    render(<UploadPanel />);
    expect(screen.getByRole('heading', { name: /add a skill/i })).toBeInTheDocument();
    expect(screen.getByRole('button', { name: /add skill/i })).toBeDisabled();
  });

  it('uploads a fresh folder and reports completion', async () => {
    vi.mocked(artifactExists).mockResolvedValue(false);
    vi.mocked(uploadArtifact).mockResolvedValue({ ok: true, name: 'demo.zip', url: 'x' });
    const user = userEvent.setup();
    render(<UploadPanel />);

    const input = screen.getByLabelText(/choose skill folder/i);
    await user.upload(input, [folderFile('demo/SKILL.md')]);
    await user.click(screen.getByRole('button', { name: /add skill/i }));

    await waitFor(() => expect(screen.getByText(/refinement complete/i)).toBeInTheDocument());
  });

  it('prompts to overwrite on collision and proceeds when confirmed', async () => {
    vi.mocked(artifactExists).mockResolvedValue(true);
    vi.mocked(uploadArtifact).mockResolvedValue({ ok: true, name: 'demo.zip', url: 'x' });
    const user = userEvent.setup();
    render(<UploadPanel />);

    await user.upload(screen.getByLabelText(/choose skill folder/i), [folderFile('demo/SKILL.md')]);
    await user.click(screen.getByRole('button', { name: /add skill/i }));

    await waitFor(() => expect(screen.getByRole('alertdialog')).toBeInTheDocument());
    await user.click(screen.getByRole('button', { name: /^overwrite$/i }));
    await waitFor(() => expect(screen.getByText(/refinement complete/i)).toBeInTheDocument());
    expect(uploadArtifact).toHaveBeenCalledWith('demo.zip', expect.any(Blob), true);
  });

  it('shows the parsed skill manifest (name + description) before storing', async () => {
    vi.mocked(artifactExists).mockResolvedValue(false);
    vi.mocked(uploadArtifact).mockResolvedValue({ ok: true, name: 'demo.zip', url: 'x' });
    const user = userEvent.setup();
    render(<UploadPanel />);

    const skill = folderFile(
      'demo/SKILL.md',
      `---\nname: demo\ndescription: A clearly identifiable description.\n---\n# Skill\n`,
    );
    await user.upload(screen.getByLabelText(/choose skill folder/i), [skill]);
    await user.click(screen.getByRole('button', { name: /add skill/i }));

    await waitFor(() => expect(screen.getByLabelText(/skill metadata/i)).toBeInTheDocument());
    expect(screen.getByText(/clearly identifiable description/i)).toBeInTheDocument();
  });
});
