import './RefineLoader.css';

interface RefineLoaderProps {
  /** Short label describing the current phase, e.g. "Compressing skill folder". */
  label: string;
}

/**
 * A loader evoking a 1970s data-refinement terminal: a slow horizontal scan
 * sweeping a row of glyph cells, with a blinking caret and the active phase
 * label. Motion is suppressed under prefers-reduced-motion.
 */
export function RefineLoader({ label }: RefineLoaderProps) {
  const cells = Array.from({ length: 24 });
  return (
    <div className="refine" role="status" aria-live="polite" aria-label={label}>
      <div className="refine-readout mono">
        <span className="refine-caret" aria-hidden="true">
          ▌
        </span>
        {label}
      </div>
      <div className="refine-grid" aria-hidden="true">
        {cells.map((_, i) => (
          <span className="refine-cell" style={{ animationDelay: `${i * 0.06}s` }} key={i} />
        ))}
        <div className="refine-scan" />
      </div>
      <div className="refine-sub mono" aria-hidden="true">
        refining data · do not disconnect
      </div>
    </div>
  );
}
