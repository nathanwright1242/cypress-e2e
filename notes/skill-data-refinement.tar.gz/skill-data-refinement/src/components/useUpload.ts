import { useCallback, useState } from 'react';
import { artifactExists, uploadArtifact } from '../api/client';
import { deriveArtifactName, zipFiles } from '../api/zip';
import { validateSkill } from '../api/validate';

export type UploadPhase =
  | 'idle'
  | 'validating'
  | 'zipping'
  | 'checking'
  | 'uploading'
  | 'needs-confirm'
  | 'done'
  | 'error';

interface UploadState {
  phase: UploadPhase;
  artifactName: string | null;
  message: string | null;
  fileCount: number;
  warnings: string[];
  meta: { name?: string; description?: string } | null;
}

const initial: UploadState = {
  phase: 'idle',
  artifactName: null,
  message: null,
  fileCount: 0,
  warnings: [],
  meta: null,
};

export function useUpload() {
  const [state, setState] = useState<UploadState>(initial);
  // hold the zipped blob between the collision prompt and the confirmed upload
  const [pending, setPending] = useState<{ name: string; blob: Blob } | null>(null);

  const reset = useCallback(() => {
    setState(initial);
    setPending(null);
  }, []);

  const doUpload = useCallback(async (name: string, blob: Blob, overwrite: boolean) => {
    setState((s) => ({ ...s, phase: 'uploading', message: 'Transmitting to storage…' }));
    try {
      await uploadArtifact(name, blob, overwrite);
      setState((s) => ({
        ...s,
        phase: 'done',
        artifactName: name,
        message: 'Refinement complete. Artifact stored.',
      }));
      setPending(null);
    } catch (e) {
      setState((s) => ({ ...s, phase: 'error', message: (e as Error).message }));
    }
  }, []);

  const submit = useCallback(
    async (files: File[]) => {
      if (files.length === 0) {
        setState({ ...initial, phase: 'error', message: 'No files selected.' });
        return;
      }
      const name = deriveArtifactName(files);

      // 1. Validate the skill structure before doing any work.
      setState({
        phase: 'validating',
        artifactName: name,
        message: 'Validating skill structure…',
        fileCount: files.length,
        warnings: [],
        meta: null,
      });
      const validation = await validateSkill(files);
      if (!validation.ok) {
        setState((s) => ({
          ...s,
          phase: 'error',
          message: validation.errors.join(' '),
          warnings: validation.warnings,
        }));
        return;
      }

      // 2. Zip the folder in the browser.
      setState((s) => ({
        ...s,
        phase: 'zipping',
        message: 'Compressing skill folder…',
        warnings: validation.warnings,
        meta: validation.meta ?? null,
      }));
      let blob: Blob;
      try {
        blob = await zipFiles(files);
      } catch (e) {
        setState((s) => ({ ...s, phase: 'error', message: (e as Error).message }));
        return;
      }

      // 3. Collision check against storage.
      setState((s) => ({ ...s, phase: 'checking', message: 'Checking storage for collisions…' }));
      const exists = await artifactExists(name);
      if (exists) {
        setPending({ name, blob });
        setState((s) => ({
          ...s,
          phase: 'needs-confirm',
          message: `An artifact named ${name} already exists.`,
        }));
        return;
      }
      await doUpload(name, blob, false);
    },
    [doUpload],
  );

  const confirmOverwrite = useCallback(async () => {
    if (!pending) return;
    await doUpload(pending.name, pending.blob, true);
  }, [pending, doUpload]);

  return {
    phase: state.phase,
    artifactName: state.artifactName,
    message: state.message,
    fileCount: state.fileCount,
    warnings: state.warnings,
    meta: state.meta,
    submit,
    confirmOverwrite,
    reset,
  };
}
