import { describe, it, expect, beforeEach, vi } from 'vitest';
import { renderHook, act, waitFor } from '@testing-library/react';

// Unit-isolate the hook: mock the HTTP client and the zip util so this test
// verifies orchestration (phase transitions, the overwrite handshake) only.
// The real client/zip behaviour is covered in their own node-env test files.
vi.mock('../api/client', () => ({
  artifactExists: vi.fn(),
  uploadArtifact: vi.fn(),
  reconstructUrl: (n: string) => `https://bucket.test/${n}`,
}));
vi.mock('../api/zip', async () => {
  const actual = await vi.importActual<typeof import('../api/zip')>('../api/zip');
  return { ...actual, zipFiles: vi.fn(async () => new Blob(['z'], { type: 'application/zip' })) };
});

import { useUpload } from './useUpload';
import { artifactExists, uploadArtifact } from '../api/client';

const VALID_SKILL = `---
name: PLACEHOLDER
description: A valid description of the skill for testing.
---
# Skill
`;

function makeFile(path: string, content?: string): File {
  // Default a valid SKILL.md whose name matches the folder so validation passes.
  const folder = path.split('/')[0];
  const body =
    content ?? (path.endsWith('SKILL.md') ? VALID_SKILL.replace('PLACEHOLDER', folder) : 'x');
  const f = new File([body], path.split('/').pop() ?? path, { type: 'text/plain' });
  Object.defineProperty(f, 'webkitRelativePath', { value: path });
  return f;
}

beforeEach(() => {
  vi.mocked(artifactExists).mockReset();
  vi.mocked(uploadArtifact).mockReset();
});

describe('useUpload', () => {
  it('starts idle', () => {
    const { result } = renderHook(() => useUpload());
    expect(result.current.phase).toBe('idle');
  });

  it('uploads a fresh folder end to end', async () => {
    vi.mocked(artifactExists).mockResolvedValue(false);
    vi.mocked(uploadArtifact).mockResolvedValue({ ok: true, name: 'fresh-skill.zip', url: 'x' });
    const { result } = renderHook(() => useUpload());
    await act(async () => {
      await result.current.submit([makeFile('fresh-skill/SKILL.md')]);
    });
    await waitFor(() => expect(result.current.phase).toBe('done'));
    expect(result.current.artifactName).toBe('fresh-skill.zip');
    expect(uploadArtifact).toHaveBeenCalledWith('fresh-skill.zip', expect.any(Blob), false);
  });

  it('enters needs-confirm when the artifact already exists', async () => {
    vi.mocked(artifactExists).mockResolvedValue(true);
    const { result } = renderHook(() => useUpload());
    await act(async () => {
      await result.current.submit([makeFile('existing-skill/SKILL.md')]);
    });
    await waitFor(() => expect(result.current.phase).toBe('needs-confirm'));
    expect(uploadArtifact).not.toHaveBeenCalled();
  });

  it('overwrites after confirmation', async () => {
    vi.mocked(artifactExists).mockResolvedValue(true);
    vi.mocked(uploadArtifact).mockResolvedValue({ ok: true, name: 'existing-skill.zip', url: 'x' });
    const { result } = renderHook(() => useUpload());
    await act(async () => {
      await result.current.submit([makeFile('existing-skill/SKILL.md')]);
    });
    await waitFor(() => expect(result.current.phase).toBe('needs-confirm'));
    await act(async () => {
      await result.current.confirmOverwrite();
    });
    await waitFor(() => expect(result.current.phase).toBe('done'));
    expect(uploadArtifact).toHaveBeenCalledWith('existing-skill.zip', expect.any(Blob), true);
  });

  it('surfaces an error when no files are selected', async () => {
    const { result } = renderHook(() => useUpload());
    await act(async () => {
      await result.current.submit([]);
    });
    expect(result.current.phase).toBe('error');
  });

  it('blocks upload when the skill fails validation (no SKILL.md)', async () => {
    const { result } = renderHook(() => useUpload());
    await act(async () => {
      await result.current.submit([makeFile('bad-skill/run.py')]);
    });
    expect(result.current.phase).toBe('error');
    expect(result.current.message).toMatch(/SKILL\.md/i);
    expect(uploadArtifact).not.toHaveBeenCalled();
  });
});
