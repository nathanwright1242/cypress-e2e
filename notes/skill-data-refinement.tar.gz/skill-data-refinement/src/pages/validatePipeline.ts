import { load, YAMLException } from 'js-yaml';

export interface PipelineValidation {
  ok: boolean;
  errors: string[];
}

interface RawStage {
  id?: unknown;
  description?: unknown;
}

/**
 * Validate pipeline YAML before it is pushed:
 *   - must parse as valid YAML (syntax errors are reported with line numbers),
 *   - must be a mapping with a `name` and a non-empty `stages` list,
 *   - every stage must carry an `id`.
 */
export function validatePipeline(text: string): PipelineValidation {
  const errors: string[] = [];

  if (!text || text.trim() === '') {
    return { ok: false, errors: ['Pipeline is empty.'] };
  }

  let doc: unknown;
  try {
    doc = load(text);
  } catch (e) {
    if (e instanceof YAMLException) {
      const line = e.mark ? e.mark.line + 1 : undefined;
      errors.push(`Syntax error${line ? ` on line ${line}` : ''}: ${e.reason}.`);
    } else {
      errors.push(`Could not parse YAML: ${(e as Error).message}.`);
    }
    return { ok: false, errors };
  }

  if (doc === null || typeof doc !== 'object' || Array.isArray(doc)) {
    return { ok: false, errors: ['Pipeline must be a YAML mapping (key: value pairs).'] };
  }

  const obj = doc as Record<string, unknown>;

  if (!obj.name || String(obj.name).trim() === '') {
    errors.push('Missing required field: name.');
  }

  const stages = obj.stages;
  if (!Array.isArray(stages) || stages.length === 0) {
    errors.push('Pipeline must define a non-empty stages list.');
  } else {
    stages.forEach((stage, i) => {
      const s = stage as RawStage;
      if (!s || typeof s !== 'object' || !s.id || String(s.id).trim() === '') {
        errors.push(`Stage ${i + 1} is missing an id.`);
      }
    });
  }

  return { ok: errors.length === 0, errors };
}
