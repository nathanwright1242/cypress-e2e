import { useMemo, useState } from 'react';
import Editor from '@monaco-editor/react';
import { pushPipeline } from '../api/client';
import { DEFAULT_PIPELINE } from './pipelineDefault';
import { validatePipeline } from './validatePipeline';

export function Pipelines() {
  const [yaml, setYaml] = useState(DEFAULT_PIPELINE);
  const [status, setStatus] = useState<{ kind: 'ok' | 'err' | null; msg: string }>({
    kind: null,
    msg: '',
  });
  const [busy, setBusy] = useState(false);

  // Live validation on every edit; the push button is gated on this.
  const validation = useMemo(() => validatePipeline(yaml), [yaml]);

  const push = async () => {
    // Re-check at submit time as a guard, even though the button is disabled.
    if (!validation.ok) {
      setStatus({ kind: 'err', msg: 'Fix the validation errors before pushing.' });
      return;
    }
    setBusy(true);
    setStatus({ kind: null, msg: 'Pushing pipeline…' });
    try {
      const res = await pushPipeline('skill-refinement', yaml);
      setStatus({ kind: 'ok', msg: `Pipeline "${res.name}" accepted by the refinement API.` });
    } catch (e) {
      setStatus({ kind: 'err', msg: (e as Error).message });
    } finally {
      setBusy(false);
    }
  };

  return (
    <section aria-labelledby="pipe-h">
      <p className="eyebrow">Refinement Control · YAML</p>
      <h2 id="pipe-h" style={{ marginTop: '0.4rem' }}>
        Pipelines
      </h2>
      <p style={{ color: 'var(--ink-mute)', maxWidth: '60ch' }}>
        Define the refinement stages for an artifact. Edit the preset below and push it to the API.
        It is validated as you type.
      </p>

      <div className="panel" style={{ padding: 0, marginTop: '1rem' }}>
        <div data-testid="monaco-host">
          <Editor
            height="440px"
            defaultLanguage="yaml"
            theme="vs-dark"
            value={yaml}
            onChange={(v) => setYaml(v ?? '')}
            options={{
              minimap: { enabled: false },
              fontFamily: 'IBM Plex Mono, monospace',
              fontSize: 13,
              scrollBeyondLastLine: false,
              padding: { top: 14 },
            }}
          />
        </div>
      </div>

      <div aria-live="polite" style={{ marginTop: '0.8rem' }}>
        {validation.ok ? (
          <p className="status status-ok mono" style={{ fontSize: '0.78rem' }}>
            ✓ Valid pipeline · {countStages(yaml)} stage(s)
          </p>
        ) : (
          <ul
            className="status status-err"
            style={{ margin: 0, paddingLeft: '1.1rem' }}
            role="alert"
          >
            {validation.errors.map((e) => (
              <li key={e}>{e}</li>
            ))}
          </ul>
        )}
      </div>

      <div style={{ display: 'flex', gap: '0.8rem', marginTop: '1rem', alignItems: 'center' }}>
        <button className="btn" onClick={push} disabled={busy || !validation.ok}>
          {busy ? 'Pushing…' : 'Push pipeline'}
        </button>
        {status.kind && (
          <span
            className={'status ' + (status.kind === 'ok' ? 'status-ok' : 'status-err')}
            role="status"
          >
            {status.msg}
          </span>
        )}
      </div>
    </section>
  );
}

// Lightweight count for the valid-state readout (validation already guarantees shape).
function countStages(text: string): number {
  const m = text.match(/^\s*-\s+id:/gm);
  return m ? m.length : 0;
}
