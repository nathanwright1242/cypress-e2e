export function Guide() {
  const steps = [
    {
      k: 'I',
      t: 'Prepare your skill folder',
      d: 'A skill is a folder containing a SKILL.md and any supporting files. Keep the top-level folder name meaningful — it becomes the artifact name.',
    },
    {
      k: 'II',
      t: 'Add for refinement',
      d: 'On Intake, choose your folder. It is validated (a root SKILL.md with name and description frontmatter), zipped in your browser, and checked for a name collision before anything is written.',
    },
    {
      k: 'III',
      t: 'Resolve collisions',
      d: 'If an artifact of the same name already exists, you are asked to confirm an overwrite. Nothing is replaced without your explicit consent.',
    },
    {
      k: 'IV',
      t: 'Define a pipeline',
      d: 'On Pipelines, edit the preset YAML to describe how an artifact should be extracted, linted, refined, and stored, then push it to the API.',
    },
  ];

  return (
    <section aria-labelledby="guide-h">
      <p className="eyebrow">Handbook · Section 4</p>
      <h2 id="guide-h" style={{ marginTop: '0.4rem' }}>
        Refinement guide
      </h2>
      <p style={{ color: 'var(--ink-mute)', maxWidth: '60ch' }}>
        These four steps describe the full lifecycle of a skill artifact, from your folder to
        refined storage.
      </p>

      <ol
        style={{
          listStyle: 'none',
          padding: 0,
          marginTop: '2rem',
          display: 'grid',
          gap: '1px',
          background: 'var(--ink-line)',
          border: '1px solid var(--ink-line)',
        }}
      >
        {steps.map((s) => (
          <li
            key={s.k}
            style={{
              display: 'grid',
              gridTemplateColumns: '72px 1fr',
              background: 'var(--ink-deep)',
            }}
          >
            <div
              className="mono"
              style={{
                display: 'flex',
                alignItems: 'center',
                justifyContent: 'center',
                fontSize: '1.4rem',
                color: 'var(--ink-teal)',
                borderRight: '1px solid var(--ink-line)',
              }}
            >
              {s.k}
            </div>
            <div style={{ padding: '1.2rem 1.4rem' }}>
              <h3 style={{ margin: '0 0 0.4rem', fontSize: 'var(--step-h3)' }}>{s.t}</h3>
              <p style={{ margin: 0, color: 'var(--ink-mute)' }}>{s.d}</p>
            </div>
          </li>
        ))}
      </ol>
    </section>
  );
}
