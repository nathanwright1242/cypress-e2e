/** Preset YAML loaded into the Monaco editor on the Pipelines page. */
export const DEFAULT_PIPELINE = `# Skill Refinement Pipeline
# Edit the stages below, then push to the refinement API.
name: skill-refinement
version: 1

source:
  artifact: my-skill.zip      # name of an uploaded skill artifact

stages:
  - id: extract
    description: Unpack the skill archive
  - id: lint
    description: Validate SKILL.md frontmatter and structure
  - id: refine
    description: Normalize and enrich skill metadata
  - id: store
    description: Write refined artifact back to storage

policy:
  on_failure: halt          # halt | continue
  retain_intermediate: true
`;
