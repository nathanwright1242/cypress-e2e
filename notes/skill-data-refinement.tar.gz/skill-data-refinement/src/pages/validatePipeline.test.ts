// @vitest-environment node
import { describe, it, expect } from 'vitest';
import { validatePipeline } from './validatePipeline';

const valid = `name: skill-refinement
version: 1
stages:
  - id: extract
    description: Unpack
  - id: store
    description: Write back
`;

describe('validatePipeline', () => {
  it('accepts well-formed pipeline YAML', () => {
    const r = validatePipeline(valid);
    expect(r.ok).toBe(true);
    expect(r.errors).toHaveLength(0);
  });

  it('reports a syntax error with a line number', () => {
    const broken = 'name: x\nstages:\n  - id: a\n   bad-indent: y';
    const r = validatePipeline(broken);
    expect(r.ok).toBe(false);
    expect(r.errors[0]).toMatch(/line \d+/i);
  });

  it('rejects YAML that is not a mapping', () => {
    const r = validatePipeline('- just\n- a\n- list');
    expect(r.ok).toBe(false);
    expect(r.errors.join(' ')).toMatch(/mapping|object/i);
  });

  it('requires a name field', () => {
    const r = validatePipeline('version: 1\nstages:\n  - id: a');
    expect(r.ok).toBe(false);
    expect(r.errors.join(' ')).toMatch(/name/i);
  });

  it('requires a non-empty stages list', () => {
    const r = validatePipeline('name: x\nstages: []');
    expect(r.ok).toBe(false);
    expect(r.errors.join(' ')).toMatch(/stages/i);
  });

  it('requires every stage to have an id', () => {
    const r = validatePipeline('name: x\nstages:\n  - description: no id here');
    expect(r.ok).toBe(false);
    expect(r.errors.join(' ')).toMatch(/id/i);
  });

  it('rejects empty input', () => {
    const r = validatePipeline('   ');
    expect(r.ok).toBe(false);
    expect(r.errors.join(' ')).toMatch(/empty/i);
  });
});
