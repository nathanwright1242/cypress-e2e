import { UploadPanel } from '../components/UploadPanel';

export function Upload() {
  return (
    <div>
      <p className="eyebrow" style={{ marginBottom: '0.8rem' }}>
        Skill Data Refinement
      </p>
      <h1
        style={{
          fontFamily: 'var(--font-display)',
          fontSize: 'var(--step-h1)',
          lineHeight: 1.02,
          margin: '0 0 1.4rem',
          letterSpacing: '-0.01em',
        }}
      >
        Refine the data.
      </h1>
      <UploadPanel />
    </div>
  );
}
