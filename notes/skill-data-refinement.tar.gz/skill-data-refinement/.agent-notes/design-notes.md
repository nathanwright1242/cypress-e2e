# Design notes

Aesthetic: cold, institutional 1970s-corporate system (Severance/MDR-inspired mood, no
trademarked names). Brand mark is the neutral "Refinery".

Palette (CSS vars --ink-*): void #061113 / deep #0A1A1D / teal #3DAFAF / cyan glow #5BC8D4 /
pale #D9E8E6 / amber alarm #E0A23D (overwrite + warnings) / clay danger #C25B4E (errors).
Type: Helvetica-narrow institutional display, Inter body, IBM Plex Mono utility.
Signature: faint CRT scanline overlay on the body; oversized display headline.
Numbered Roman markers on the Guide encode the real I–IV lifecycle, not decoration.

Copy: subtle, plain-verb labels ("Add skill", "Refine the data.") rather than overt
show references. Errors/warnings speak in the interface's voice and say what to fix.
