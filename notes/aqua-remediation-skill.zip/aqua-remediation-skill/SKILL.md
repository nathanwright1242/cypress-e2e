---
name: aqua-vuln-remediation
description: >
  Given a project repo, pull its latest Aqua Security container scan, classify every CVE as
  base-image-inherited vs user-controlled, and produce an actionable remediation report:
  which approved base image tag to upgrade to (data-driven, with CVE clearance counts),
  which CVEs are resolved by upgrading the in-house framework (and to which version),
  which CVEs the team can fix directly, and which are blocked on the framework team.
  Use whenever a user asks about container vulnerabilities, CVE remediation, base image
  upgrades, Aqua scan results, or "what security issues does project X have".
---

# Aqua Vulnerability Remediation Skill

## Inputs
- `repo_path` (required): local checkout or repo identifier of the project
- `config.yaml`: org-level config (Artifactory URL, Aqua URL, approved base image catalog,
  framework coordinates). Same config serves every project — nothing project-specific here.

## Pipeline (run in order)

### 1. Resolve the project's image — `scripts/resolve_image.py`
- Scan repo for `Dockerfile`, `docker-compose.yml`, CI yml (`.gitlab-ci.yml`, Jenkinsfile,
  GitHub workflows) using the glob patterns in config.
- Extract the image name/path (registry repo) from the build/push step or compose file.
- Query Artifactory for the most recently published tag of that image.
  - NOTE: "latest published" may drift from "deployed". If deploy metadata is available
    (e.g. ArgoCD / Helm values / deployment annotations), prefer the deployed tag. TODO.

### 2. Pull the Aqua scan — `scripts/aqua_client.py`
- Authenticate with the bearer-token utility (wraps your existing utility — see TODO markers).
- Fetch vulnerabilities for `registry/repo:tag`, including per-finding **layer digest /
  resource path** attribution. This attribution is what powers everything downstream.

### 3. Classify base vs user-controlled — `scripts/classify.py`
**Layer-lineage matching** (solves "custom images built off approved bases"):
- Fetch the image's ordered layer digest list (from the registry manifest, or Aqua's image API).
- For each approved base image in the catalog, fetch its layer digests (cached).
- The approved image whose digest list is the **longest matching prefix** of the project
  image's digest list is the true parent — even through intermediate custom images,
  because layers are content-addressed and inherited verbatim.
- Any CVE attributed to a layer inside that shared prefix → **base-image bucket**.
- Everything above the prefix → **user-controlled bucket**.

### 4. Suggest a base image upgrade — `scripts/suggest_base_upgrade.py`
This is data-driven, not guesswork:
- List all tags of the matched approved base image from Artifactory, semver-sorted,
  keeping only tags newer than the current one.
- For each candidate tag, pull **its** Aqua scan (approved images are scanned too).
- Compute clearance: `cleared = project_base_CVEs - candidate_CVEs`.
- Recommend:
  - `minimal`: the lowest tag clearing >= clearance_threshold (config, default 90%)
    of base CVEs — least upgrade risk.
  - `best`: the tag clearing the most CVEs (often latest).
  - Always list **residual CVEs** (present even in the best candidate) so nobody chases
    unfixable findings.
- If the parent couldn't be matched to the catalog (truly custom base), fall back to
  recommending migration to the closest approved image by OS family/package overlap,
  flagged as `migration_required: true`.

### 5. Framework (BOM) resolution — two parts

**Offline, run once + on each framework release — `scripts/build_framework_matrix.py`:**
- For each release tag of the in-house framework (listed from Artifactory), download its
  BOM / parent POM and compute the *effective* managed dependency set:
  - resolve `<properties>` placeholders
  - recursively resolve `<dependencyManagement><scope>import</scope>` BOMs
- Persist `framework_matrix.json`: `{fw_version: {"group:artifact": version}}`.
- This file is the entire "framework mapping" — regenerate it on new releases via CI hook.

**At scan time — inside `scripts/classify.py`:**
For each user-controlled CVE (Aqua gives package + `fix_version`):
1. **Provenance check**: is the package managed by the framework at the project's current
   framework version (present in `matrix[current_fw]`) and *not* overridden by the project
   (no explicit version in the project's own pom/lockfile)? If the project's framework
   version is unknown, detect it from the pom parent / dependency on the framework artifact.
2. If framework-managed → search the matrix for the **minimum framework version** whose
   managed version of the package >= the CVE's fix version.
   - Found → **framework-upgrade bucket**: "upgrade framework to v"
   - Not found in any release → **blocked-on-framework bucket** (this is the demand
     signal to aggregate across projects and hand to the framework team)
3. Not framework-managed → **directly-actionable bucket**: ordinary dependency bump.

### 6. Report — `scripts/report.py`
Emit JSON + human-readable Markdown with four buckets:
1. **Base image**: "bump FROM approved-base:1.2 → 1.5, clears 14/15 base CVEs; residual: CVE-..."
2. **Framework upgrade**: "framework 2.3 → 2.6 clears these 9 CVEs"
3. **Directly actionable**: per-package bump list with fix versions
4. **Blocked on framework**: CVEs with no fixing framework release (escalation list)

Plus headline metrics: total CVEs, % auto-actionable, by severity.

## Known fuzzy edges (review and decide)
- **BOM version ranges / Gradle platforms**: matrix builder currently assumes Maven BOM
  semantics. Gradle version catalogs need a parallel parser.
- **Multi-stage Dockerfiles**: final stage's FROM is what matters; resolve_image handles
  the last stage only.
- **Project overrides of framework deps**: detected via explicit version in project pom;
  Gradle `resolutionStrategy` overrides are a TODO.
- **Approved image rebuilds under the same tag**: prefix matching uses digests, so a
  mutable tag that was rebuilt won't match old children — match against all historical
  digests of catalog tags if Artifactory retains them.
