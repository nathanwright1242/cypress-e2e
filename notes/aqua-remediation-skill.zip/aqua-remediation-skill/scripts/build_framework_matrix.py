"""Step 5a (offline): build framework_matrix.json from the in-house framework's BOMs.

Run once to backfill all releases, then on every new framework release (CI hook).
Resolves <properties> placeholders and recursively imports nested BOMs, producing the
effective managed-dependency set per framework version:

  {"2.6.0": {"com.fasterxml.jackson.core:jackson-databind": "2.15.3", ...}, ...}

Maven semantics only for now; Gradle version catalogs are a TODO (see SKILL.md).
"""
import json
import os
import re
import xml.etree.ElementTree as ET

import requests
import yaml

NS = {"m": "http://maven.apache.org/POM/4.0.0"}


def _txt(el, path):
    found = el.find(path, NS)
    return found.text.strip() if found is not None and found.text else None


def fetch_pom(group: str, artifact: str, version: str, cfg: dict) -> ET.Element:
    art = cfg["artifactory"]
    token = os.environ.get(art["token_env_var"], "")
    gpath = group.replace(".", "/")
    url = (f"{art['base_url']}/libs-release/{gpath}/{artifact}/{version}/"
           f"{artifact}-{version}.pom")
    r = requests.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=30)
    r.raise_for_status()
    return ET.fromstring(r.text)


def resolve_bom(group: str, artifact: str, version: str, cfg: dict,
                props: dict | None = None, depth: int = 0) -> dict[str, str]:
    """Effective dependencyManagement for a BOM, with property + import resolution."""
    if depth > 5:
        return {}
    root = fetch_pom(group, artifact, version, cfg)

    props = dict(props or {})
    props.setdefault("project.version", version)
    for p in root.findall("m:properties/*", NS):
        props[p.tag.split("}")[-1]] = (p.text or "").strip()

    def interp(v: str) -> str:
        return re.sub(r"\$\{([^}]+)\}", lambda m: props.get(m.group(1), m.group(0)), v or "")

    managed: dict[str, str] = {}
    for dep in root.findall("m:dependencyManagement/m:dependencies/m:dependency", NS):
        g, a = interp(_txt(dep, "m:groupId")), interp(_txt(dep, "m:artifactId"))
        v, scope = interp(_txt(dep, "m:version")), _txt(dep, "m:scope")
        if scope == "import" and _txt(dep, "m:type") == "pom":
            # nested BOM: its entries apply, but ours win on conflict (Maven nearest-wins)
            for k, nv in resolve_bom(g, a, v, cfg, props, depth + 1).items():
                managed.setdefault(k, nv)
        elif g and a and v:
            managed[f"{g}:{a}"] = v
    return managed


def list_framework_versions(cfg: dict) -> list[str]:
    fw, art = cfg["framework"], cfg["artifactory"]
    token = os.environ.get(art["token_env_var"], "")
    gpath = fw["group_id"].replace(".", "/")
    url = (f"{art['base_url']}/api/search/versions?g={fw['group_id']}"
           f"&a={fw['bom_artifact_id']}&repos=libs-release")
    r = requests.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=30)
    r.raise_for_status()
    return [x["version"] for x in r.json().get("results", [])]


if __name__ == "__main__":
    cfg = yaml.safe_load(open("config.yaml"))
    fw = cfg["framework"]
    matrix = {}
    for v in list_framework_versions(cfg):
        try:
            matrix[v] = resolve_bom(fw["group_id"], fw["bom_artifact_id"], v, cfg)
            print(f"resolved {v}: {len(matrix[v])} managed deps")
        except Exception as e:  # keep going; report gaps
            print(f"WARN {v}: {e}")
    with open(fw["matrix_path"], "w") as f:
        json.dump(matrix, f, indent=2, sort_keys=True)
    print(f"wrote {fw['matrix_path']} ({len(matrix)} framework versions)")
