"""Step 4: suggest which approved base image tag to upgrade to — data-driven.

For each newer tag of the matched approved base, pull ITS Aqua scan and compute which of
the project's base-layer CVEs it clears. No guessing from changelogs.
"""
import json
import re
import sys

import yaml

from aqua_client import fetch_findings


def _ver_key(v: str):
    return [int(x) for x in re.findall(r"\d+", v)] or [0]


def newer_tags(image_repo: str, current_tag: str, all_tags: list[str]) -> list[str]:
    cur = _ver_key(current_tag)
    return sorted((t for t in all_tags if _ver_key(t) > cur), key=_ver_key)


def suggest(matched_base: str, base_findings: list[dict], all_tags: list[str],
            cfg: dict) -> dict:
    image_repo, current_tag = matched_base.rsplit(":", 1)
    project_cves = {f["cve"] for f in base_findings}
    threshold = cfg["base_upgrade"]["clearance_threshold"]

    candidates = []
    for tag in newer_tags(image_repo, current_tag, all_tags):
        cand_cves = {f["cve"] for f in fetch_findings(image_repo, tag, cfg)}
        cleared = project_cves - cand_cves
        candidates.append({"tag": tag,
                           "cleared": sorted(cleared),
                           "cleared_count": len(cleared),
                           "residual": sorted(project_cves & cand_cves)})

    if not candidates:
        return {"recommendation": None,
                "note": "no newer tags of the matched base exist; "
                        "escalate base CVEs to the base-image team"}

    best = max(candidates, key=lambda c: c["cleared_count"])
    minimal = next((c for c in candidates
                    if project_cves and c["cleared_count"] / len(project_cves) >= threshold),
                   best)
    return {"current": matched_base,
            "minimal_upgrade": minimal,      # lowest tag clearing >= threshold
            "best_upgrade": best,            # clears the most
            "all_candidates": candidates}


if __name__ == "__main__":
    cfg = yaml.safe_load(open("config.yaml"))
    classified = json.load(open(sys.argv[1]))   # output of classify.py
    tags = json.load(open(sys.argv[2]))         # tag list for the matched base (Artifactory)
    print(json.dumps(suggest(classified["matched_base"],
                             classified["base_image"], tags, cfg), indent=2))
