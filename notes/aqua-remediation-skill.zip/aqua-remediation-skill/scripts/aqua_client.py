"""Step 2: authenticate to Aqua and pull the latest scan for an image.

Wraps your existing bearer-token utility (config: aqua.token_command).
Output shape per finding (normalized):
{
  "cve": "CVE-2024-1234", "severity": "high",
  "package": "openssl",            # or "com.fasterxml.jackson.core:jackson-databind"
  "installed_version": "3.0.1", "fix_version": "3.0.7",
  "resource_type": "package" | "library",   # os pkg vs app dep — Aqua provides this
  "layer_digest": "sha256:...",              # which layer introduced it
  "resource_path": "/app/lib/jackson-databind-2.13.0.jar"
}
"""
import json
import subprocess
import sys

import requests


def get_token(cfg: dict) -> str:
    return subprocess.check_output(cfg["aqua"]["token_command"], shell=True, text=True).strip()


def fetch_findings(image_repo: str, tag: str, cfg: dict) -> list[dict]:
    base = cfg["aqua"]["base_url"]
    headers = {"Authorization": f"Bearer {get_token(cfg)}"}
    registry = cfg["aqua"]["registry_name"]
    findings, page = [], 1
    while True:
        # Aqua SaaS/CSP vulnerability endpoint; adjust path to your Aqua version. TODO verify.
        r = requests.get(
            f"{base}/api/v2/images/{registry}/{image_repo}/{tag}/vulnerabilities",
            headers=headers, params={"page": page, "pagesize": 200}, timeout=60)
        r.raise_for_status()
        body = r.json()
        for v in body.get("result", []):
            findings.append({
                "cve": v.get("name"),
                "severity": (v.get("aqua_severity") or v.get("severity", "")).lower(),
                "package": v.get("resource", {}).get("name"),
                "installed_version": v.get("resource", {}).get("version"),
                "fix_version": v.get("fix_version"),
                "resource_type": v.get("resource", {}).get("type"),
                "layer_digest": v.get("resource", {}).get("layer_digest")
                                 or v.get("first_found_layer"),
                "resource_path": v.get("resource", {}).get("path"),
            })
        if page * 200 >= body.get("count", 0):
            break
        page += 1
    return findings


def fetch_layer_digests(image_repo: str, tag: str, cfg: dict) -> list[str]:
    """Ordered layer digests for the image. Try Aqua's image API first; fall back to
    the Artifactory registry manifest if needed (TODO)."""
    base = cfg["aqua"]["base_url"]
    headers = {"Authorization": f"Bearer {get_token(cfg)}"}
    registry = cfg["aqua"]["registry_name"]
    r = requests.get(f"{base}/api/v2/images/{registry}/{image_repo}/{tag}",
                     headers=headers, timeout=60)
    r.raise_for_status()
    layers = r.json().get("history") or r.json().get("layers") or []
    return [l.get("id") or l.get("digest") for l in layers if (l.get("id") or l.get("digest"))]


if __name__ == "__main__":
    import yaml
    cfg = yaml.safe_load(open("config.yaml"))
    image_repo, tag = sys.argv[1], sys.argv[2]
    out = {"findings": fetch_findings(image_repo, tag, cfg),
           "layers": fetch_layer_digests(image_repo, tag, cfg)}
    print(json.dumps(out, indent=2))
