"""Step 3+5b: classify findings into four buckets.

  base_image        -> fixed by bumping the approved base
  framework_upgrade -> fixed by upgrading the in-house framework to version X
  direct            -> team bumps the dependency themselves
  blocked_framework -> framework-managed, but NO framework release fixes it yet

Inputs: findings + project layer digests (aqua_client), approved-catalog layer digests,
framework_matrix.json, the project's current framework version, and the set of packages
the project explicitly overrides in its own pom/lockfile.
"""
import json
import re


# ---------- layer lineage ----------

def match_parent_base(project_layers: list[str],
                      catalog_layers: dict[str, list[str]]) -> tuple[str | None, int]:
    """Find the approved image whose layer list is the longest prefix of the project's.

    catalog_layers: {"docker-local/base/ubi9-minimal:9.4-1": [digest, ...], ...}
    Returns (catalog_image_tag | None, shared_prefix_len).
    Content-addressed layers mean this works even through intermediate custom images.
    """
    best, best_len = None, 0
    for image_tag, layers in catalog_layers.items():
        n = 0
        for a, b in zip(project_layers, layers):
            if a != b:
                break
            n += 1
        # require the *whole* candidate to be a prefix (it's a complete base image)
        if n == len(layers) and n > best_len:
            best, best_len = image_tag, n
    return best, best_len


def split_by_layer(findings: list[dict], project_layers: list[str],
                   prefix_len: int) -> tuple[list[dict], list[dict]]:
    base_digests = set(project_layers[:prefix_len])
    base, user = [], []
    for f in findings:
        (base if f.get("layer_digest") in base_digests else user).append(f)
    # Fallback when Aqua didn't attribute a layer: os packages -> base, libraries -> user.
    # Reasonable default; revisit if your images install os packages on top of the base.
    for f in user[:]:
        if not f.get("layer_digest") and f.get("resource_type") == "package":
            user.remove(f)
            base.append(f)
    return base, user


# ---------- framework matrix lookup ----------

def _ver_key(v: str):
    return [int(x) for x in re.findall(r"\d+", v or "0")] or [0]


def classify_user_findings(user_findings: list[dict],
                           matrix: dict[str, dict[str, str]],
                           current_fw: str,
                           project_overrides: set[str]) -> dict:
    """matrix: {fw_version: {"group:artifact" or pkg name: managed_version}}"""
    fw_versions = sorted(matrix.keys(), key=_ver_key)
    newer_fw = [v for v in fw_versions if _ver_key(v) > _ver_key(current_fw)]
    current_managed = matrix.get(current_fw, {})

    buckets = {"framework_upgrade": [], "blocked_framework": [], "direct": []}
    for f in user_findings:
        pkg, fix = f.get("package"), f.get("fix_version")
        managed = pkg in current_managed and pkg not in project_overrides
        if not managed:
            buckets["direct"].append(f)
            continue
        if not fix:  # no fix exists anywhere yet
            buckets["blocked_framework"].append({**f, "reason": "no upstream fix"})
            continue
        fixing = next((v for v in newer_fw
                       if _ver_key(matrix[v].get(pkg, "0")) >= _ver_key(fix)), None)
        if fixing:
            buckets["framework_upgrade"].append({**f, "framework_fix_version": fixing})
        else:
            buckets["blocked_framework"].append(
                {**f, "reason": f"no framework release ships {pkg} >= {fix}"})
    return buckets


if __name__ == "__main__":
    import sys
    data = json.load(open(sys.argv[1]))          # output of aqua_client.py
    catalog = json.load(open(sys.argv[2]))       # cached catalog layer digests
    matrix = json.load(open(sys.argv[3]))        # framework_matrix.json
    current_fw = sys.argv[4]
    overrides = set(sys.argv[5].split(",")) if len(sys.argv) > 5 else set()

    parent, plen = match_parent_base(data["layers"], catalog)
    base, user = split_by_layer(data["findings"], data["layers"], plen)
    out = {"matched_base": parent,
           "base_image": base,
           **classify_user_findings(user, matrix, current_fw, overrides)}
    print(json.dumps(out, indent=2))
