"""Step 1: resolve the project's container image from repo files + Artifactory.

Output: {"image_repo": "docker-local/team/app", "tag": "1.4.2", "source_file": "Dockerfile"}
"""
import glob
import json
import os
import re
import sys

import requests
import yaml


def load_config(path="config.yaml"):
    with open(path) as f:
        return yaml.safe_load(f)


def find_image_repo(repo_path: str, cfg: dict) -> dict:
    """Scan known files for the image path the project publishes."""
    for pattern in cfg["image_discovery"]["patterns"]:
        for fp in glob.glob(os.path.join(repo_path, pattern), recursive=True):
            text = open(fp, errors="ignore").read()
            # docker-compose / CI yml: look for image: lines pointing at our registry
            m = re.search(r"image:\s*[\"']?([\w\-./]+/[\w\-./]+?)(?::[\w.\-]+)?[\"']?\s*$",
                          text, re.MULTILINE)
            if m and not fp.endswith(("Dockerfile",)):
                return {"image_repo": m.group(1), "source_file": fp}
            # CI push step:  docker push registry/repo:tag
            m = re.search(r"docker\s+(?:push|build[^\n]*-t)\s+([\w\-./]+/[\w\-./]+?)(?::|\s)",
                          text)
            if m:
                return {"image_repo": m.group(1), "source_file": fp}
    raise SystemExit(f"Could not determine image path from files in {repo_path}; "
                     "add the pattern to config.image_discovery or pass --image explicitly.")


def latest_artifactory_tag(image_repo: str, cfg: dict) -> str:
    """Most recently published tag for the image in Artifactory."""
    art = cfg["artifactory"]
    token = os.environ.get(art["token_env_var"], "")
    # Docker registry v2 API via Artifactory; sort by created date using AQL for accuracy.
    # Simpler tags-list approach shown; TODO swap to AQL if tag count is large.
    repo, path = image_repo.split("/", 1)
    url = f"{art['base_url']}/api/docker/{repo}/v2/{path}/tags/list"
    r = requests.get(url, headers={"Authorization": f"Bearer {token}"}, timeout=30)
    r.raise_for_status()
    tags = r.json().get("tags", [])
    if not tags:
        raise SystemExit(f"No tags found for {image_repo}")
    # TODO: prefer deployed tag from ArgoCD/Helm metadata when available.
    # Heuristic: highest semver-ish tag; falls back to lexicographic.
    def key(t):
        nums = [int(x) for x in re.findall(r"\d+", t)[:4]]
        return (len(nums) > 0, nums)
    return sorted(tags, key=key)[-1]


def last_stage_base(repo_path: str) -> str | None:
    """FROM of the final stage in the Dockerfile (useful cross-check for lineage)."""
    for fp in glob.glob(os.path.join(repo_path, "**/Dockerfile*"), recursive=True):
        froms = re.findall(r"^FROM\s+([\S]+)", open(fp, errors="ignore").read(), re.MULTILINE)
        if froms:
            return froms[-1].split(" ")[0]
    return None


if __name__ == "__main__":
    repo_path = sys.argv[1] if len(sys.argv) > 1 else "."
    cfg = load_config()
    info = find_image_repo(repo_path, cfg)
    info["tag"] = latest_artifactory_tag(info["image_repo"], cfg)
    info["dockerfile_base_hint"] = last_stage_base(repo_path)
    print(json.dumps(info, indent=2))
