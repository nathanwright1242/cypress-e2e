"""Step 6: emit the remediation report (JSON + Markdown) from classify + upgrade outputs."""
import json
import sys
from collections import Counter


def build(classified: dict, upgrade: dict, image: str) -> tuple[dict, str]:
    sev = Counter(f["severity"] for b in ("base_image", "framework_upgrade",
                                          "blocked_framework", "direct")
                  for f in classified.get(b, []))
    total = sum(sev.values())
    actionable = (len(classified.get("base_image", []))
                  + len(classified.get("framework_upgrade", []))
                  + len(classified.get("direct", [])))

    report = {"image": image,
              "summary": {"total_cves": total, "by_severity": dict(sev),
                          "actionable": actionable,
                          "actionable_pct": round(100 * actionable / total, 1) if total else 0},
              "base_image_upgrade": upgrade,
              "buckets": classified}

    md = [f"# Remediation report — `{image}`",
          f"**{total} CVEs** | actionable now: **{report['summary']['actionable_pct']}%** "
          f"| {dict(sev)}", ""]
    if upgrade.get("minimal_upgrade"):
        m = upgrade["minimal_upgrade"]
        md += [f"## 1. Base image — bump `{upgrade['current']}` → `{m['tag']}`",
               f"Clears **{m['cleared_count']}/{len(classified['base_image'])}** base CVEs. "
               f"Residual: {', '.join(m['residual']) or 'none'}", ""]
    fw = classified.get("framework_upgrade", [])
    if fw:
        target = max(f["framework_fix_version"] for f in fw)
        md += [f"## 2. Framework — upgrade to `{target}`",
               f"Clears {len(fw)} CVEs: " + ", ".join(f["cve"] for f in fw), ""]
    direct = classified.get("direct", [])
    if direct:
        md += ["## 3. Direct dependency bumps"] + [
            f"- {f['package']} {f['installed_version']} → {f.get('fix_version') or '?'} "
            f"({f['cve']}, {f['severity']})" for f in direct] + [""]
    blocked = classified.get("blocked_framework", [])
    if blocked:
        md += ["## 4. Blocked on framework team (escalate)"] + [
            f"- {f['cve']} in {f['package']} — {f.get('reason')}" for f in blocked]
    return report, "\n".join(md)


if __name__ == "__main__":
    classified = json.load(open(sys.argv[1]))
    upgrade = json.load(open(sys.argv[2]))
    image = sys.argv[3] if len(sys.argv) > 3 else "unknown"
    report, md = build(classified, upgrade, image)
    json.dump(report, open("remediation_report.json", "w"), indent=2)
    open("remediation_report.md", "w").write(md)
    print(md)
