# Stack-specific practices

Quick reference for detecting a stack and applying its conventions. Read only the section matching the repo. Always let the *actual repo config* override anything here.

## How to detect the stack

| Signal file | Stack |
|---|---|
| `package.json` | Node / JS / TS |
| `pyproject.toml`, `requirements.txt`, `setup.py` | Python |
| `go.mod` | Go |
| `Gemfile` | Ruby |
| `Cargo.toml` | Rust |
| `pom.xml`, `build.gradle` | Java / Kotlin (JVM) |
| `composer.json` | PHP |
| `*.csproj`, `*.sln` | C# / .NET |

Check the lockfile and engine/version fields for exact versions — practices differ across major versions.

---

## Node / JavaScript / TypeScript
- **Test runners:** vitest, jest, node:test, mocha. Check `scripts.test` in `package.json` and the config file present (`vitest.config.*`, `jest.config.*`).
- **Package manager:** infer from lockfile — `package-lock.json` (npm), `pnpm-lock.yaml` (pnpm), `yarn.lock` (yarn), `bun.lockb` (bun). Use the one already in use.
- **Style:** respect eslint + prettier configs; match `import` vs `require`, semicolons, and ESM/CJS as the repo does. For TS, honor `tsconfig` strictness — don't loosen it.
- **TDD:** colocate or mirror per the repo (`__tests__/`, `*.test.ts`, `*.spec.ts`). Run a single test file fast during red-green; full suite before commit.

## Python
- **Test runners:** pytest (most common) or unittest. Check `pyproject.toml`/`pytest.ini`/`tox.ini`.
- **Env/deps:** poetry, uv, pip-tools, or plain pip/venv — detect from `pyproject.toml`/lockfiles and use the existing tooling.
- **Style:** ruff/flake8 + black/isort; follow line length and import ordering from config. Honor type hints and run mypy/pyright if the repo does.
- **TDD:** tests in `tests/`, files `test_*.py`, functions `test_*`. Use fixtures over setup boilerplate where the repo already does.

## Go
- **Tests:** built-in `testing`; files `*_test.go`, functions `TestXxx`. Table-driven tests are idiomatic — follow existing examples.
- **Style:** `gofmt`/`goimports` are non-negotiable; keep errors explicit and wrapped (`fmt.Errorf("...: %w", err)`).
- **TDD:** `go test ./...`; use subtests (`t.Run`) for cases.

## Ruby
- **Tests:** RSpec (`spec/`, `*_spec.rb`) or Minitest (`test/`, `*_test.rb`). Detect from `Gemfile`.
- **Style:** rubocop config governs; match it exactly.
- **TDD:** for Rails, mirror app structure under `spec/`; use existing factories/fixtures.

## Rust
- **Tests:** `#[cfg(test)]` modules + `#[test]`; integration tests in `tests/`.
- **Style:** `cargo fmt` + `cargo clippy`; prefer `Result` and the `?` operator per existing code.
- **TDD:** `cargo test`.

## JVM (Java / Kotlin)
- **Tests:** JUnit (4 or 5 — check imports) or TestNG; Kotlin may use Kotest. Build via maven or gradle as present.
- **Style:** match existing formatter (google-java-format, ktlint, spotless config).
- **TDD:** `mvn test` / `gradle test`; mirror `src/main` layout under `src/test`.

## PHP
- **Tests:** PHPUnit or Pest (`tests/`). Detect from `composer.json`.
- **Style:** php-cs-fixer / PSR-12 per config.
- **TDD:** `vendor/bin/phpunit` or `vendor/bin/pest`.

## C# / .NET
- **Tests:** xUnit, NUnit, or MSTest (check the test `.csproj` references).
- **Style:** `dotnet format`; follow `.editorconfig`.
- **TDD:** `dotnet test`.

---

## If the stack isn't listed
Find the test command (CI config, README, Makefile, or `scripts`), the formatter/linter, and one existing test to copy the pattern from. The meta-rule holds everywhere: **discover the repo's actual conventions and mirror them** rather than importing defaults.
