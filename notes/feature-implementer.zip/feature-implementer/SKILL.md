---
name: feature-implementer
description: Implement a feature in an existing codebase from a description, the disciplined way — plan first, build with TDD, take the least intrusive path, and commit precisely. Use this whenever the user asks to "implement", "add", "build", or "create" a feature, fix a bug as a feature change, or hands over a feature description / ticket / spec and wants it built in their repo. Trigger even when the user doesn't say "TDD" or "plan" explicitly — this skill exists to bring that discipline to any feature-build request. Do NOT use for greenfield scaffolding of a brand-new project, pure research/explanation, or one-line throwaway edits where ceremony would be noise.
---

# Feature Implementer

Implement a feature into an *existing* codebase the way a careful senior engineer would: understand the repo, agree on a plan, build test-first, change as little as possible, and leave a clean, reviewable commit history.

The cardinal rule: **never start editing code before the plan is approved and the commit identifier is known.** Rushing into edits is the most common way these tasks go wrong.

## Workflow at a glance

1. Understand the repo and the request
2. Ask clarifying questions (batch them — don't drip-feed)
3. Get the commit identifier
4. Present a plan and wait for approval
5. Implement with TDD, least-intrusive path
6. Commit precisely as you go
7. Verify and hand off

Work through these in order. Steps 2–4 happen *before* any code changes.

---

## 1. Understand the repo and the request

Before anything else, learn the lay of the land. You cannot follow a repo's best practices if you don't know what they are.

Inspect (don't guess):
- **Tech stack & versions** — language, framework, and their versions (`package.json`, `pyproject.toml`/`requirements.txt`, `go.mod`, `Gemfile`, `Cargo.toml`, `pom.xml`, etc.).
- **Test setup** — the test runner, where tests live, and the naming convention. Run the existing suite if feasible to confirm it's green *before* you touch anything. A red baseline is critical information.
- **Conventions** — read `CONTRIBUTING.md`, `CLAUDE.md`/`AGENTS.md`, linter/formatter configs (eslint, prettier, ruff, black, rubocop), and `.editorconfig`. Skim a few nearby source files to absorb the house style: naming, error handling, file layout, how dependencies are injected.
- **Where the feature belongs** — find the modules/layers the feature touches and how similar features were built. Mirror existing patterns rather than importing your own.

Load `references/stack-practices.md` for stack-specific conventions and TDD tooling once you know the stack.

If the codebase contradicts a "best practice" you'd otherwise apply, **the codebase wins.** Consistency with the surrounding code matters more than abstract ideals. Note the discrepancy in your plan if it's significant, but don't unilaterally "fix" it.

## 2. Ask clarifying questions

Feature descriptions are almost always underspecified. Resolve ambiguity *before* planning, not mid-implementation. Gather your questions and ask them together so the user answers in one pass.

Worth clarifying when unclear:
- **Scope boundaries** — what's explicitly in vs. out for this change.
- **Behavior on edge cases** — empty inputs, errors, concurrency, permissions, limits.
- **Interfaces / contracts** — exact API shape, function signature, UI states, data format.
- **Non-functional needs** — performance, security, accessibility, backward compatibility, migrations.
- **Acceptance criteria** — how the user will know it's done and correct.

Don't ask about things you can answer yourself by reading the code — that wastes the user's time. Only surface genuine forks where guessing wrong would mean rework. If the request is fully clear, say so and move on rather than manufacturing questions.

## 3. Get the commit identifier

Ask the user for an **identifier to prepend to every commit** (e.g., a ticket key like `PROJ-123`, an issue number like `#456`, or a short tag). Confirm the format they want before you start.

All commits for this feature begin with that identifier. See the commit section below for exact formatting.

If they don't have one, offer a sensible default (e.g., a short slug derived from the feature name) and let them confirm.

## 4. Present a plan and wait for approval

Write a concise, concrete plan and **stop for approval before editing any code.** This is a hard gate, not a formality — it's the user's chance to redirect cheaply.

Structure the plan as:

```
## Plan: <feature name>

**Understanding:** <1–2 sentences restating the feature in your words>

**Approach:** <the least-intrusive path you'll take and why>

**Changes (least → most intrusive):**
- <file/module>: <what changes and why>
- ...

**Tests (written first):**
- <test name>: <behavior it pins down>
- ...

**Out of scope:** <what you're deliberately not doing>

**Risks / assumptions:** <anything that could bite, migrations, breaking changes>

**Commit identifier:** <confirmed identifier>
```

Keep it tight — enough to review, not a novel. After presenting, wait. Don't begin implementing until the user approves or adjusts.

## 5. Implement with TDD

Build the feature test-first, in small red-green-refactor loops:

1. **Red** — write a failing test that specifies the next slice of behavior. Run it; confirm it fails *for the right reason* (asserting behavior, not tripping on a typo).
2. **Green** — write the minimum code to pass. Resist gold-plating.
3. **Refactor** — clean up names, duplication, and structure with the tests as your safety net. Keep the suite green.

Repeat per slice of behavior, smallest meaningful increment each time. Cover the happy path and the edge cases surfaced in clarification. Run the *whole* suite periodically, not just the new tests, to catch regressions early.

If the codebase has no tests at all, say so and propose a light approach (e.g., introduce a minimal test for the new code) rather than forcing a heavy framework on a repo that rejects one. Adapt to reality.

### Least-intrusive path

Prefer the change that touches the fewest lines and surprises the reader least:
- Extend and reuse existing functions, patterns, and abstractions before adding new ones.
- Keep the diff focused on the feature; resist drive-by refactors, reformatting, and dependency bumps unless required (and if required, do them in a *separate* commit).
- Don't change public interfaces or behavior that other code relies on unless the feature demands it; when it does, call it out.
- Add a dependency only when there's no reasonable in-repo way to do it, and flag it for the user.
- Match the existing style exactly — this keeps the diff about *behavior*, not noise.

A small, boring, consistent change is a feature, not a limitation. The goal is a diff a reviewer can understand at a glance.

## 6. Commit precisely

Commit in **logical units keyed to a single coherent change** — not one giant commit at the end, and not a commit per file. A good rule: each commit should leave the suite green and be describable in one clear sentence. Typically the test and the implementation for a behavior slice land together.

**Format:** every commit message starts with the confirmed identifier, followed by a concise, imperative summary of the key change.

```
<IDENTIFIER>: <imperative summary of the key change>

<optional body: why, not what — context a reviewer needs>
```

**Example 1**
Identifier: `PROJ-123`
Change: added the failing test + validator for empty cart checkout
Output: `PROJ-123: reject checkout when cart is empty`

**Example 2**
Identifier: `#456`
Change: wired the new rate-limit middleware into the auth routes
Output: `#456: apply rate limiting to auth endpoints`

Keep the summary under ~72 characters, imperative mood ("add", not "added"), and specific to the *key* change — not a list of every file. Use the body for the reasoning if the change isn't self-evident. **Confirm with the user before pushing** anything to a remote; committing locally is fine, but pushing, opening PRs, or any remote-affecting action needs explicit approval.

## 7. Verify and hand off

Before declaring done:
- Run the full test suite and the linter/formatter; everything green and clean.
- Re-read the diff as a reviewer would — is it minimal, consistent, and obvious?
- Check the feature against the acceptance criteria from step 2.
- Summarize for the user: what you built, the commits made (with identifiers), test coverage added, anything deferred or risky, and any follow-ups. Mention any remote action (push/PR) you're holding for their go-ahead.

---

## Guardrails

- **Plan gate is real** — no code edits before approval and a known identifier.
- **Don't invent requirements** — when the spec is silent and it matters, ask; don't assume.
- **Stay in scope** — surface tempting adjacent fixes to the user instead of folding them in silently.
- **Codebase conventions beat personal preference**, every time.
- **Confirm before any remote or irreversible action** (push, force-push, PR, deleting branches).
- **If tests can't run** in the environment, say so explicitly and write the tests anyway so the user can run them — don't silently skip TDD.
